# FOR19: Green Digitalization and App Development 
NHH | Spring 2024

### Group members:
* Adoncia Tan
* Andreas Caniaris
* Bjørnar Berge
* Britney Charles
* Daniel Hu Øren
* Herman Wilter
* Jasmine Athea Næss
* Klara Evelina Palkint ​​

### Known bugs after latest commit:
